import requests
import json
import os
import sys

# Login to Shiprocket and get the token
def sr_login(email, password):
    url = 'https://apiv2.shiprocket.in/v1/external/auth/login'
    headers = {
        'Content-Type': 'application/json'
    }
    login_data = json.dumps({
        "email": email,
        "password": password
    })

    try:
        response = requests.post(url, headers=headers, data=login_data)
        response.raise_for_status()
        data = response.json()
        return data['token'] if 'token' in data else None
    except requests.exceptions.RequestException as err:
        print(f"Login failed: {err}")
        sys.exit(1)

# Fetch the shipping rate using Shiprocket API
def get_shipping_rate(token, pickup_postcode, delivery_postcode, weight, declared_value):
    url = 'https://apiv2.shiprocket.in/v1/external/courier/serviceability'
    params = {
        'pickup_postcode': pickup_postcode,
        'delivery_postcode': delivery_postcode,
        'weight': weight,
        'cod': 1,
        'declared_value': declared_value,
        'rate_calculator': 1
    }
    
    headers = {
        'Authorization': f'Bearer {token}',
        'Content-Type': 'application/json'
    }

    try:
        response = requests.get(url, headers=headers, params=params)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as err:
        print(f"Error fetching shipping rate: {err}")
        sys.exit(1)

# Main function to call the login and rate fetch functions
def main():
    email = "ds161141@gmail.com"
    password = "D@syi2sn3NKRir"

    if not email or not password:
        print("Please set your Shiprocket email and password in environment variables SHIPROCKET_EMAIL and SHIPROCKET_PASSWORD.")
        sys.exit(1)

    # Example input values for testing
    pickup_postcode = 700008
    delivery_postcode = 700009
    weight = 5  # in kg
    declared_value = 2000  # in currency unit

    # Login to get token
    token = sr_login(email, password)
    
    # Fetch shipping rate
    if token:
        result = get_shipping_rate(token, pickup_postcode, delivery_postcode, weight, declared_value)
        print(json.dumps(result, indent=4))

if __name__ == '__main__':
    main()
