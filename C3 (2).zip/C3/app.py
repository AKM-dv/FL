from flask import Flask, render_template, request, redirect, flash, url_for,g,jsonify,session
from werkzeug.utils import secure_filename
import os
import mysql.connector
import ast
from datetime import datetime
import requests



app = Flask(__name__)


app.secret_key = '696969696969'
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['UPLOAD_cat_FOLDER'] = 'static/uploads/category'

app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif','webp'}

def get_db():
    if 'db' not in g:
        g.db = mysql.connector.connect(
            user='root',
            host='localhost',
            password='8307802643',
            database='ecom',
            charset="utf8",
            port="3306",
        )
    return g.db

@app.teardown_appcontext
def close_db(error):
    if 'db' in g:
        g.db.close()

def execute_query(query, data=None):
    db = get_db()
    with db.cursor() as cursor:
        cursor.execute(query, data)
        db.commit()


def fetch_data(query, data=None, one=False):
    db = get_db()
    with db.cursor() as cursor:
        cursor.execute(query, data)
        if one:
            return cursor.fetchone()
        return cursor.fetchall()



def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS



@app.route('/')
def main():
    cmd = "Select * from product"
    data = fetch_data(cmd)
    data1 = fetch_data("select id,name from category")
    return render_template('index.html',data=data,cats= data1)



@app.route('/admin')
def admin():
   

    return render_template('admin.html')


@app.route('/add_to_cart', methods=['POST'])
def add_to_cart():
    data = request.json
    pid = data.get('pidv')
    cmd = f"select dp,title from product where id={pid}"
    dpr = fetch_data(cmd)
    dp = dpr[0][0]
    name = dpr[0][1]

    quantity = data.get('quantity_valuev')
    variants = data.get('var_respv')
    newpd = [pid,quantity,variants,dp,name]
    
    if 'cart' not in session:
        session['cart'] = []  # 
    cart_list = session['cart']
    cart_list.append(newpd)
    session['cart'] = cart_list 


    cart = session['cart']
   

    return  cart



    # Process the data (e.g., save to database, etc.)

    # Send a response back to the client
    return jsonify({"message": "Data received successfully!"})


@app.route('/reducecart',methods=['POST','GET'])
def reducecart():
    data = request.json
    pidd = data.get('pidval')
    # Sample list
    products = session['cart']

    # The PID you want to update
    target_pid = pidd
    print(pidd)

    # Iterate over the list
    for product in products:
      pid, quantity, variants, dp, name = product

      if pid == target_pid:
        print(pid)
        # Reduce the quantity by 1
        new_quantity = int(quantity) - 1
        product[1] = str(new_quantity)
        print(products)
        print(product[1])

        if new_quantity == 0:
            # print(f"Product '{name}' removed")
        
            products.remove(product)
            print(products)

    # Print the updated list
    session['cart'] = products
    cart = session['cart']
   

    return  cart


@app.route('/buyitnow',methods=['POST','GET'])
def buynow():

    data = request.json
    pid = data.get('pidv')
    cmd = f"select dp,title from product where id={pid}"
    dpr = fetch_data(cmd)
    dp = dpr[0][0]
    name = dpr[0][1]

    quantity = data.get('quantity_valuev')
    variants = data.get('var_respv')
    newpd = [pid,quantity,variants,dp,name]
    
    if 'cart' not in session:
        session['cart'] = []  # 
    cart_list = session['cart']
    cart_list.append(newpd)
    session['cart'] = cart_list 


    cart = session['cart']
   

    

    

    return   jsonify({"message": "Data received successfully!"})
      




# @app.route('/user_login',methods=['POST','GET'])
# def user_login():
#     if request.method == "GET":
#         return render_template('login.html')
#     password = request.form['password']
#     userid = request.form['userid']
#     print(password,userid)
#     return "ok bro"


@app.route('/removecart',methods=['POST','GET'])
def removecart():
    data = request.json
    pidd = data.get('pidval')
    # Sample list
    products = session['cart']

    # The PID you want to update
    target_pid = pidd
    print(pidd)

    # Iterate over the list
    for product in products:
      pid, quantity, variants, dp, name = product

      if pid == target_pid:
        print(pid)
        # Reduce the quantity by 1
        new_quantity = int(quantity) - 1
        product[1] = str(new_quantity)
        print(products)
        print(product[1])

       
            # print(f"Product '{name}' removed")
    
        products.remove(product)
        print(products)

    # Print the updated list
    session['cart'] = products
    cart = session['cart']
   

    return  cart



@app.route('/increasecart',methods=['POST','GET'])
def increasecart():
    data = request.json
    pidd = data.get('pidval')
    # Sample list
    products = session['cart']

    # The PID you want to update
    target_pid = pidd
    print(pidd)

    # Iterate over the list
    for product in products:
      pid, quantity, variants, dp, name = product

      if pid == target_pid:
        print(pid)
        # Reduce the quantity by 1
        new_quantity = int(quantity) + 1
        product[1] = str(new_quantity)
        print(products)
        print(product[1])

        
    # Print the updated list
    session['cart'] = products
    cart = session['cart']
   

    return  cart



@app.route('/getcartdata')
def getcartdata():
    cartdata = session['cart']
    print(cartdata)
    try:
          # Raise an exception for HTTP errors
        data = cartdata # Assuming the response is in JSON format
        return jsonify(data)  # Return the fetched data as JSON
    except requests.exceptions.RequestException as e:
        return jsonify({'error': str(e)}), 500  # Return an error if the request fails

    return cartdata


@app.route('/product/<int:pid>')
def product(pid):   
    # session.pop('cart')
    cmd = f"select * from product where id={pid} "
    data = fetch_data(cmd)
    data1 = fetch_data("select id,name from category")
    datada = fetch_data("select * from product")

  #   fetch the category also for similar products
    return render_template('product.html',data=data,cats=data1,datada=datada)


@app.route('/size-chart')
def size_chart():
    return render_template('size-chart.html')



@app.route('/pu/<int:pid>',methods=['POST','GET'])
def pu(pid):
    if request.method =="POST": 
     
        fcount = pid
        images = request.files.getlist('images')
        

        title  = request.form['title']
        sku  = request.form['sku']
        desc  = request.form['desc']
        op = request.form['op']
        dp = request.form['dp']
        yt = request.form['yt']
        quantity =request.form['quantity']
        variant = request.form['variantData']
        category  = request.form['optionSelect']
        quantity = request.form['quantity']
        pid  = fcount

        print(title,sku,desc,op,dp,yt,quantity,variant,fcount)
        cmd = f"update product set title='{title}',descrip='{desc}',op='{op}',dp='{dp}',pid='{pid}',variants='{variant}',sku='{sku}',yt='{yt}',quant='{quantity}' where id='{pid}'"
        execute_query(cmd)  
        cmd = f"select lis from category where name='{category}'"
        data = fetch_data(cmd)
        print(data)
       
        if data != [] :
            lis = data[0]

            listt = ast.literal_eval(lis)
            listt.append(pid)
        else:
            listt = []
            listt.append(pid)
        cmd = f"update category set lis='{listt}' where name='{category}'"    
        execute_query(cmd)

       

       



        
        # Save each image with a unique filename
        for i, image in enumerate(images):
            if image and image.filename.endswith('.webp'):
                filename = f'{fcount}_v{i}.webp'
                image.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                print("-------- saved ----------")
            else:
                # Handle invalid file types if needed
                pass
        return redirect(url_for('pds'))
        
       
        
        # Collect URLs of the saved images for preview
    
        
        
    cmd = f"select * from product where id='{pid}'"
    data = fetch_data(cmd)
    title = data[0][0]
    desc = data[0][1]
    op = data[0][2]
    dp = data[0][3]
    pid =  data[0][4]
    variants = data[0][5]
    sku = data[0][6]
    yt = data[0][7]
    quant = data[0][9]
    
    dets = [title,desc,op,dp,pid,variants,sku,yt,quant]


    return render_template('pu.html',dets = dets)


@app.route('/checkout',methods=['POST','GET'])
def checkout():
    if request.method == 'POST':
        pass
    data = session['cart']

    return render_template('checkout.html',data=session['cart'])
    



@app.route('/checkcop',methods=["POST","GET"])
def checkcop():
     print("---------")
     data = request.json
     print(data)
     cmd = f"select status,percentage from coupon where name='{data['key1']}'"
     try :
          
        data = fetch_data(cmd)
        status = data[0][0]
        percentage = data[0][1]
        response_data = {'status': status,'percentage': percentage}
     except:
        response_data = {'status': "000",'percentage': "000"}
        return jsonify(response_data)
          
   
     return jsonify(response_data)
     
@app.route('/addp',methods=["POST","GET"])
def addp():
    if request.method =="POST":
        cmd = "select count(*) from product"
        data = fetch_data(cmd)
        count = data[0][0]
        fcount = int(count) + 1
        images = request.files.getlist('images')
        

        title  = request.form['title']
        sku  = request.form['sku']
        desc  = request.form['desc']
        op = request.form['op']
        dp = request.form['dp']
        yt = request.form['yt']
        quantity =request.form['quantity']
        variant = request.form['variantData']
        category  = request.form['optionSelect']
        quantity = request.form['quantity']

        pid  = fcount

        print(title,sku,desc,op,dp,yt,quantity,variant,fcount)
        cmd = f"insert into product values('{title}','{desc}','{op}','{dp}','{pid}','{variant}','{sku}','{yt}','{pid}',{quantity})"
        execute_query(cmd)  
        cmd = f"select lis from category where name='{category}'"
        data = fetch_data(cmd)
        print(data)
       
        if data != [] :
            lis = data[0]

            listt = ast.literal_eval(lis)
            listt.append(pid)
        else:
            listt = []
            listt.append(pid)
        cmd = f"update category set lis='{listt}' where name='{category}'"    
        execute_query(cmd)

       

       



        
        # Save each image with a unique filename
        for i, image in enumerate(images):
            if image and image.filename.endswith('.webp'):
                filename = f'{fcount}_v{i}.webp'
                image.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                print("-------- saved ----------")
            else:
                # Handle invalid file types if needed
                pass
        
       
        
        # Collect URLs of the saved images for preview
    
        return redirect(url_for('pds'))
        
        

    return render_template('addp.html')

@app.route('/pds')
def pds():
    cmd = "select title,id from product "
    data= fetch_data(cmd)
    return render_template('pds.html',data=data)


@app.route('/cat')

def admin_category():
    if request.method=="POST":
         pass
    else:
        cmd="select id,name from category"
        data=fetch_data(cmd)
        
        return render_template('categories_admin.html',data=data)



@app.route('/add_category',methods=["POST","GET"])

def add_category():

    if request.method=="POST":

        data = fetch_data("select count(*) from category")
        psrno = data[0][0] 
         
        psrno = psrno + 1


        img1 = request.files['images']

        if img1 and allowed_file(img1.filename):
                filename = f"{psrno}c.webp"
                img1.save(os.path.join(app.config['UPLOAD_cat_FOLDER'], filename))
        else:
            pass

        catname = request.form['catname']
        pdliraw = request.form['pdli']
        desc = request.form['desc']
        
        data_list = pdliraw.split(',')

        # Remove empty elements from the list (if any)
        data_list = [item for item in data_list if item]

        # Convert string elements to integers
        pdli = [int(item) for item in data_list]
                
        
                

       

        
 

        cmd=f'insert into category values("{psrno}","{catname}","{str(pdli)}","{desc}")'
        print(cmd)

        print(pdli)

        execute_query(cmd)

        return redirect(url_for('admin_category'))

        


    cmd = "Select id,title from product"

    
    data = fetch_data(cmd)
    


  


    return render_template('add_category.html',data = data)


    



@app.route('/cu/<int:cid>',methods=["POST","GET"])

def  update_cat(cid):
     if request.method=="POST":
         
        psrno = cid


        img1 = request.files['images']

        if img1 and allowed_file(img1.filename):
                filename = f"{psrno}c.webp"
                img1.save(os.path.join(app.config['UPLOAD_cat_FOLDER'], filename))
        else:
            pass

        catname = request.form['catname']
        pdliraw = request.form['pdli']
        desc = request.form['desc']
        
        data_list = pdliraw.split(',')

        # Remove empty elements from the list (if any)
        data_list = [item for item in data_list if item]

        # Convert string elements to integers
        pdli = [int(item) for item in data_list]
                
        
                

       

        


        cmd=f"update category set name='{catname}',lis='{pdli}',description='{desc}' where id='{psrno}'"
        print(cmd)

        execute_query(cmd)

        return redirect(url_for('admin_category'))

          
     cmd=f"select * from category where id='{cid}'"
     data1 = fetch_data(cmd)

     cmd = "Select id from product"

    
     data = fetch_data(cmd)
     
     return render_template('cu.html',data1=data1,data=data,catid=cid,)
     


@app.route('/couponadd',methods=['POST','GET'])

def couponadd():
      if request.method=="POST":
           name = request.form['name']
           pen = request.form['pen']
           state = 'on'
           print(name)

           cmd = f"insert into coupon values('{name}','{pen}','{state}')"
           execute_query(cmd)

           return redirect(url_for('couponadd'))
           
      cmd = "select * from coupon"
      data= fetch_data(cmd)
      
      return render_template('coupon.html',data=data)

@app.route("/category",methods=['POST','GET'])
def category():

    data1 = fetch_data("select id,name from category")
    return render_template('category.html',cats=data1)



@app.route('/cashfree',methods=['POST','GET'])
def cashfree():
    
     now = datetime.now()

    # Extract seconds and milliseconds
     seconds = now.second
     milliseconds = now.microsecond // 1000

# Combine seconds and milliseconds
     combined = seconds * 1000 + milliseconds

     oid = combined
     print("here",oid)
     oam = request.form['abc']

     
     cname = request.form['fname']
     cadd = request.form['address']
     state  = request.form['state']
     pin  = request.form['pin']
     cphone = request.form['phone']
     cmail = request.form['mail']
     pdli = session['cart']
     city  = request.form['city']


     session['order']=[cname,cadd,pdli,oid,pin,state, cmail, city,oam,cphone]
     print(oam)
     oaa = int(oam)
     url = "https://test.cashfree.com/api/v1/order/create"
     payload = {
    "appID" :"TEST102909258fe22df42e2fe4dbd31252909201",
    "secretKey" : "cfsk_ma_test_1ba8a3d30d336f9b3444cc9f71ec1cf1_6a5866b1",
    "orderId" : oid,
    "orderAmount" : oaa,
    "orderCurrency" : "INR",
    "customerName" : cname,
    "customerEmail" : cmail,
    "customerPhone" : cphone,
    "returnUrl" : "https://www.neighshop.com",
    "notifyUrl" : "",
}
     response = requests.request("POST",url,data=payload)
     response_data = response.json()
     print(response_data)

     payment_link = response_data.get("paymentLink")

    #  print(payment_link)



     return redirect(payment_link)


@app.route('/saveorder',methods=['POST','GET'])
def saveorder():
    return "OK JI"

if __name__ == '__main__':
    if not os.path.exists(app.config['UPLOAD_FOLDER']):
        os.makedirs(app.config['UPLOAD_FOLDER'])
    app.run(debug=True,port=7500)
