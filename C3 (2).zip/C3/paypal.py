import requests
import json

# PayPal API credentials
client_id = 'AWZ0gdkw5xucDFhVOp0YyjMXwIHZo0ccfUqpdkdEHh7FJ2Biawz8mw-A7Rphp7mm1d2kSx2yjOJDKmb3'
client_secret = 'EFs_5m_sn_xjroRVg-yBlHbLTh-QlQPzoRmGrsQ-EyVMUjNsoNP2KEcvYkVt4Y4CuHfAAd3eWmmJm6BP'

# PayPal API endpoint
paypal_api_url = 'https://api-m.paypal.com'  # Use 'https://api-m.paypal.com' for live

# Step 1: Get an access token from PayPal
def get_access_token():
    url = f'{paypal_api_url}/v1/oauth2/token'
    headers = {
        'Accept': 'application/json',
        'Accept-Language': 'en_US',
    }
    data = {
        'grant_type': 'client_credentials'
    }
    response = requests.post(url, headers=headers, data=data, auth=(client_id, client_secret))
    response.raise_for_status()  # Raise an error if the request failed
    access_token = response.json()['access_token']
    return access_token

# Step 2: Create a payment and get the approval link
def create_payment():
    access_token = get_access_token()
    url = f'{paypal_api_url}/v1/payments/payment'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {access_token}',
    }
    payment_data = {
        "intent": "sale",
        "redirect_urls": {
            "return_url": "https://example.com/your-return-url",
            "cancel_url": "https://example.com/your-cancel-url"
        },
        "payer": {
            "payment_method": "paypal"
        },
        "transactions": [{
            "amount": {
                "total": "10.00",
                "currency": "USD"
            },
            "description": "Your payment description here"
        }]
    }
    response = requests.post(url, headers=headers, data=json.dumps(payment_data))
    response.raise_for_status()  # Raise an error if the request failed
    payment_info = response.json()
    
    # Extract the approval URL from the response
    for link in payment_info['links']:
        if link['rel'] == 'approval_url':
            approval_url = link['href']
            return approval_url
    return None

# Generate the PayPal payment link
payment_link = create_payment()
print(f'Payment Link: {payment_link}')
